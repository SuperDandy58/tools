import json
import time
import datetime
import threading
import os
from log_mng import LogMng
from modbus_io import ModbusIO
import paho.mqtt.client as mqtt
class MainApp:
    def __init__(self):
        config_j = json.load(open('config.json','r'))
        if os.path.isfile('config.json'):
            config_j = json.load(open('config.json','r'))
        self.log = LogMng(output_path=config_j["output_path"])
        server_conf = config_j["server"]
        self.is_stopping = False
        self.is_running = False

        self.modbusPb = ModbusIO(self.log)
        self.modbusSb = mqtt.Client(protocol=mqtt.MQTTv311)
        self.modbusP = threading.Thread(target=self.read_switch_loop)
        self.modbusP.start()
        self.modbusS = threading.Thread(target=self.write_switch_loop)
        self.modbusS.start()
       
    def main_loop(self):
        try:
            while True:
                time.sleep(1)
                self.is_running = True
        except KeyboardInterrupt:
            self.is_stopping = True
            self.modbusPb.connectClose()
            self.modbusSb.loop_stop
            print("Break")
        if self.modbusPb:
            self.modbusP.join()
            self.modbusS.join()

    def read_switch_loop(self):
        while True:
            if self.is_stopping:
                break
            if not self.is_running:
                continue
            time.sleep(3)
            self.modbusPb.readSwitchState()

    def write_switch_loop(self):
        print("write_switch_loop")
        # ハンドラー設定
        self.modbusSb.on_connect = ModbusIO.on_connect
        self.modbusSb.on_message = ModbusIO.on_message
        # 接続
        host = '127.0.0.1'
        port = 1883
        self.modbusSb.connect(host, port=port, keepalive=60)
        # 受信ループ
        self.modbusSb.loop_start()
                   
if __name__ == '__main__':
    MainApp = MainApp()
    MainApp.main_loop()