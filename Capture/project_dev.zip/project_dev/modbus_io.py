from pymodbus.client import ModbusTcpClient
import paho.mqtt.client as mqtt
from log_mng import LogMng
class ModbusIO():
    aaa = ''
    def __init__(self, LogMng):
        self.client = client = ModbusTcpClient('127.0.0.1', port=1502)
        self.log = LogMng
        
        # 定数定義
        self.host = '127.0.0.1'
        self.port = 1883
        self.topic = 'topic/data'
        self.payload = 'Hello MQTT!'

        # プロトコルを v3.1.1 を指定
        self.mqpb_client = mqtt.Client(protocol=mqtt.MQTTv311)

        
    def readSwitchState(self):
        self.client.write_coil(1, True)
        result = self.client.read_coils(1,1)
        self.log.output_info("readSwitchState")
        self.mqtt_publish()
        #print(result.bits[0])
        
    def connectClose(self):
        self.log.output_info("connectClose")
        self.client.close()
        
    def mqtt_publish(self):
        # 接続
        self.mqpb_client.connect(self.host, port=self.port, keepalive=60)
        # パブリッシュ
        self.mqpb_client.publish(self.topic, self.payload)
        # 切断
        self.mqpb_client.disconnect()
     
    # 接続
    def on_connect(client, userdata, flags, rc):

        topic = 'topic/data'
        # 戻り値チェック
        print("Connected with result code " + str(rc))
        # サブスクライブ
        client.subscribe(topic)

    # 受信
    def on_message(client, userdata, msg):
        print("on_message")        
        print('topic:[' + msg.topic + '] payload:[' + str(msg.payload) + ']')
