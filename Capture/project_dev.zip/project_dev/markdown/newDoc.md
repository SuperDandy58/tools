
# 目次
- [目次](#目次)
- [1. 開発仕様概略](#1-開発仕様概略)
  - [1.1. 全体イメージ](#11-全体イメージ)
  - [1.2. modbus通信](#12-modbus通信)
  - [1.3. mosquiito](#13-mosquiito)
- [2. 環境構築](#2-環境構築)
  - [2.1. 環境構築手順](#21-環境構築手順)
  - [2.2. 環境設定モジュール](#22-環境設定モジュール)
  - [3. 参考情報](#3-参考情報)


# 1. 開発仕様概略
## 1.1. 全体イメージ
## 1.2. modbus通信
## 1.3. mosquiito


# 2. 環境構築

## 2.1. 環境構築手順
| No  | 設定対象   | 設定内容       |     |
| :-: | :-------: | :------------ | :-: |
| 1   | Hyper-V   | 仮想マシン作成 |
| 2   | Ubuntu    | 共有フォルダ準備<br>画面解像度変更 |
| 3   | Python    | Projectフォルダー作成(venv)<br>パッケージインストール |
| 4   | modbus    |        TD |

## 2.2. 環境設定モジュール
| No | 設定対象   | 設定内容       |
| :-:| :-------: | :------------ |
| 2  | Ubuntu    | ubuntu-22.04.3-desktop-amd64.iso |
| 3  | Python    | Projectフォルダー作成(venv)<br>パッケージインストール |
| 4  | pymodbus  |        TD |
| 5  | mosquiito |        TD |
| 6  | docker    |        TD |

* Hyper-V
1. 仮想マシン作成
![Alt text](image-1.png)
![Alt text](image-2.png)
![Alt text](image-3.png)
![Alt text](image-4.png)
![Alt text](image-5.png)
![Alt text](image-6.png)
![Alt text](image-7.png)
![Alt text](image-8.png)

![Alt text](image-9.png)
![Alt text](image-10.png)

![Alt text](image-11.png)
![Alt text](image-12.png)
![Alt text](image-13.png)
![Alt text](image-14.png)
![Alt text](image-15.png)
![Alt text](image-16.png)
![Alt text](image-17.png)
![Alt text](image-18.png)


![Alt text](image-19.png)
1. 数字付き2


* Ubuntu
1. 共有フォルダ準備
【Windows側】
* アカウント作成（ローカルアカウント）
* 共有元フォルダー作成(comFolder)
* 共有設定
  1. 共有：詳細な共有 > アクセス許可
  2. セキュリティ：アクセス許可を変更（フルコントロール）



【Ubuntu側】
* 共有先フォルダー作成(comArea)
```command
sudo mkdir /comArea
sudo vi /etc/fstab
\\192.168.0.15\comFolder    /comArea cifs    username=dandy58,password=manager
sudo reboot
```
* マウント(comArea)
```command
sudo mount /comArea
```

1. 画面解像度変更
```
【Ubuntu側】

```package
# コメント
sudo apt install linux-tools-generic linux-cloud-tools-generic
sudo reboot
sudo gedit /etc/default/grub
GRUB_CMDLINE_LINUX_DEFAULT="･･･ video=hyperv_fb:2048x900"
sudo update-grub
sudo reboot
```

* Python
1. Projectフォルダー作成(venv)
```package
python3 -V    #python 3.10.12
sudp apt install python3-pip
sudo apt install python3.10-venv
mkdir -p ~/venv
cd ~/venv/
python3 -m venv project_dev
cd project_dev
source ./project_dev/bin/activate  #deactivate
```

2. パッケージインストール
requirements.txt
```package
paho-mqtt==1.6.1
pymodbus==3.6.2
```

3. コマンド
```package
# ■ インストール
# mqtt
pip install paho-mqtt
# modbus
pip install pymodbus
# Mosquitto(Broker)
sudo apt-get install mosquitto
# Mosquittoクライアント
sudo apt-get install mosquitto-clients

# ■ mosquitto起動
# システムの起動
sudo systemctl start mosquitto
# システムの状態確認
sudo systemctl status mosquitto
# システムの終了
sudo systemctl stop mosquitto

# ■ mosquitto動作確認
#Subscriberの起動(Terminal A)
mosquitto_sub -h localhost -t test
#Publisherの起動(Terminal B)
mosquitto_pub -h localhost -t test -m "test message"
```
4. VSCode拡張機能
Python Indent
Code Runner
Better Comments
Zenkaku
indent-rainbow
autoDocstring
Draw.io Integration
PlantUML
Markdown Preview Mermaid Support
IntelliCode


* docker
```package
# ■ インストール
sudo apt update
sudo apt install ca-certificates curl gnupg lsb-release
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install docker-ce docker-ce-cli containerd.io
sudo gpasswd -a $(whoami) docker
sudo mkdir ~/.docker
sudo chown $USER:$USER /home/$USER/.docker -R
sudo chgrp $USER /var/run/docker.sock
sudo service docker restart
sudo apt install docker-compose-plugin
docker version
docker compose version


```


## 3. 参考情報
 [Data-Driven Engineering](https://apmonitor.com/dde/index.php/Main/ModbusTransfer)

  [pythonでMQTT送受信](https://qiita.com/hsgucci/items/6461d8555ea1245ef6c2)

  [【MQTT】MQTTの導入 mosquittoのインストール/動作確認まで](https://qiita.com/koichi_baseball/items/8fa9e0bdbe6d0aebe57d)

  [Python言語の「Paho」MQTTクライアントの使用法](https://www.emqx.com/ja/blog/how-to-use-mqtt-in-python)

  [PyModbus HP](https://pymodbus.readthedocs.io/en/latest/index.html)