import os
import datetime
import traceback

class LogMng():
    def __init__(self, output_path=''):
        self.output_path=''
        if os.path.isdir(output_path):
            self.output_path = output_path + '/'
    def output_info(self, msg):
        self._output('[INFO]' + msg)
    def output_warning(self, msg):
        self._output('[WARN]'+msg)    
    def output_error(self, msg):
        self._output('[ERROR]'+msg)
    def output_exception(self, e):
        self.output_error(''.join(traceback.format_exception_only(type(e), e)))
    def output_exc_info(self, exc_type, exc_value, exc_traceback):
        self.output_error(''.join(traceback.format_exception(exc_type,exc_value,exc_traceback)))
    def _output(self, msg):
        now_date=datetime.datetime.now()
        msg=now_date.strftime('%Y.%m.%d %H:%M:%S.%f')+ ' '+msg
        print(msg)
        #file_name=self.output_path+'log_'+now_date.strftime('%Y%m%d')+'.log'
        #with open(file_name,'a') as f:
        #    f.writelines(msg+'\n')

