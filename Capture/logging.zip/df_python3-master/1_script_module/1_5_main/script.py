import module

print(f"module.pyでの__name__: {module.__name__}")
print(f"script.pyでの__name__: {__name__}")