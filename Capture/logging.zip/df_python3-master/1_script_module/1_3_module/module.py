def add(a, b):
    y = a + b
    return y