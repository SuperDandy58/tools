import module
# from module import add

def main():
    y = module.add(1, 3)
    # y = add(1, 3)
    print(y)

if __name__ == "__main__":
    main()