def process1():
    print("print process1")

def process2():
    print("print process2")

def main():
    process1()
    process2()

if __name__ == "__main__":
    main()
