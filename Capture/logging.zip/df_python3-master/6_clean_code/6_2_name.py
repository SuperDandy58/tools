# PascalCase, camelCase, snake_case

CONSTANT_VARIABLE = 3
sample_variable = 0


class SampleClass:
    def __init__(self):
        pass

    def sample_method(self):
        pass

    def sample_method(self):
        pass


def sample_function():
    pass
