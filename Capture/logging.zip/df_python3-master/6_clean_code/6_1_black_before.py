sample_var="a"
sample_list = [1.21,32.4,23.4]
sample_y = sample_list[0]+sample_list[2]

def sample_func(a,b,c):
    y=a+b+c
    return y

print ("Hello, World")
sample_var . upper()
sample_list [2]

class SampleClass:
    def __init__(self):
        pass
    def sample_method(self):
        pass
    def sample_method(self):
        pass