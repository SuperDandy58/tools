from package1 import add_module

print(add_module.add(1, 2))