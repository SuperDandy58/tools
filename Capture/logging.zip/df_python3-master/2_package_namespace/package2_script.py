import package2

print(package2.add(1, 2))