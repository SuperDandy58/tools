import package4

a = "sample_a"

print(package4.a)
print(a)