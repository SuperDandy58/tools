__all__ = ["print1", "print2"]

def print1():
    print("print1")

def print2():
    print("print2")

def print3():
    print("print3")