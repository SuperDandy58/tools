import package3

print(dir(package3))
print(package3.add(1, 2))
print(package3.sub(1, 2))
package3.print1()
package3.print2()
# package3.print3()