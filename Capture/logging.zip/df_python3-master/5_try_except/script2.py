# 成功
try:
    print("Hello")
except:
    print("ERROR")
else:
    print("SUCCESS")
finally:
    print("finish")

# exceptの実行
try:
    print(Hello)
except:
    print("ERROR")
else:
    print("SUCCESS")
finally:
    print("finish")