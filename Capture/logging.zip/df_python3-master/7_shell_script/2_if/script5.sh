#!/bin/bash

arg1=$1

if [ $arg1 = "a" ]; then
    echo "a"
elif [ $arg1 = "b" ]; then
    echo "b"
else
    echo "None"
fi