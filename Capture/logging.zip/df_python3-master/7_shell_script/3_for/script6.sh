#!/bin/bash

sample_list=(1 1 1)

for i in ${sample_list[@]}
do
    echo $i
done

for i in 1 2 3
do
    echo $i
done