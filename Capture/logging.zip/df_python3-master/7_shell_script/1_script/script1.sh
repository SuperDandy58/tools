#!/bin/bash

echo "Hello World"
pwd
ls
