
## 環境構築
```python
$ docker-compose up -d
http://localhost:8888 
!pip install [pythonライブラリ]
```
D:\DevWorkStrage\Docker\JupyterLab
[参考] [url](https://qiita.com/hgaiji/items/edf71435d0565257f980)

## 1.7. テーブル

|イメージ名|説明|
|:---|:---|
|base-notebook|Jupyter Notebook 5.0.x。科学計算ライブラリは含まない|
|minimal-notebook|ase-notebook に pandoc と texlive などのドキュメント変換ツールを追加|
|scipy-notebook|pandas や scikit-learn など、Python でのデータ分析ライブラリを含む|
|datascience-notebook|cipy-notebook に R と Julia を追加。R の plyr などは conda で管理|
|tensorflow-notebook|scipy-notebook に tensorflow を追加。GPUのサポートはありません|
|pyspark-notebook|scipy-notebook に Spark と Hadoop が追加。Mesos のクライアントも含む|
|all-spark-notebook|pyspark-notebook に R と Toree および Spylon を追加|
|r-notebook|minimal-notebook に R を追加。plyr などは conda で管理|
[参考] [url](https://qiita.com/kshigeru/items/ea174d6bcacc474f2a51)


## コード
```python
function hello(){
　return "hello world!";
}
```

データの読込
データの中身確認
データの部分抽出
データの状態確認
欠損値への対応
データの集計
データの可視化
データの出力
https://www.youtube.com/watch?v=ZQZ38rK28Gk